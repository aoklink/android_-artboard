package com.linkfeeling.android.art.board.core.ui;

import android.graphics.drawable.Drawable;

public interface IBackgroundDrawableProvider {
    Drawable provide(String name,int index);
}
