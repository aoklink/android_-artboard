package com.linkfeeling.android.art.board.core;

public class CoreManifest {
}
