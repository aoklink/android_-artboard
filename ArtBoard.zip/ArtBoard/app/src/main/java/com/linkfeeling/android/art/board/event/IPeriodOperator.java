package com.linkfeeling.android.art.board.event;

public interface IPeriodOperator extends IListenerOperator {
    void reCall();

    void pause();
}
