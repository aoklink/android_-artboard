package com.linkfeeling.android.art.board.core.event;

public interface IEventManifest {

    String PERIOD_GET_DATA = "PERIOD_GET_DATA";

    String REFRESH_USER_BOARD = "REFRESH_USER_BOARD";

    String REFRESH_USER_COUNT = "REFRESH_USER_COUNT";
}
