package com.linkfeeling.android.art.board.event;

public interface IListenerOperator {
    void cancel();
}
