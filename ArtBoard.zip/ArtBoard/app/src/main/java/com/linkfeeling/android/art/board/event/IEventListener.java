package com.linkfeeling.android.art.board.event;

public interface IEventListener<T> {
    void on(T data);
}
